public class TileMap {
	Tile[][] tileMap;
	int rows;
	int cols;
	
	public TileMap(int rows, int cols) {
		tileMap = new Tile[rows][cols];
		this.rows = rows;
		this.cols = cols;
	}
	
	public void printMap() {
		String outString = "";
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				outString = outString + "["  + tileMap[i][j].getTileType().toString() + "]";
			}
			System.out.println(outString);
			outString = "";
		}
	}
	
	public void fillMap(int complexity) {
		RandomTile tileMapRand = new RandomTile(complexity);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				tileMap[i][j] = new Tile(tileMapRand.GetRandomTile(), i , j);
			}
		}
	}
	
	public void emptyMap() {
		tileMap = new Tile[rows][cols];
	}

	public Tile[][] getTileMap() {
		return tileMap;
	}

	public void setTileMap(Tile[][] tileMap) {
		this.tileMap = tileMap;
	}
	
	public void shiftDown() {
		for (int i = 0; i < rows; i++) {
			
		}
	}
	
	public void findMatches() {
		TileType currType;
		//read horizontally and then vertically and clear triples and more
		//horiz
		for(int i = 0; i < rows; i++) {
			for (int j = 0; j < cols - 2; j++) {
				currType = tileMap[i][j].getTileType();
				if (tileMap[i][j+2] == null) {
					break;
				}
				
				if (currType == tileMap[i][j + 1].getTileType() && currType == tileMap[i][j + 2].getTileType()) {
					//rewards points for a 3 match
					//System.out.println("3000 points" + i + ":" + j);
					tileMap[i][j] = new Tile(TileType.EMP, i, j);
					tileMap[i][j + 1] = new Tile(TileType.EMP, i, j);
					tileMap[i][j + 2] = new Tile(TileType.EMP, i, j);
				}
			}
		}
		
		//vertical
		for (int j = 0; j < cols; j++) {
			for (int i = 0; i < rows - 2; i++) {
				currType = tileMap[i][j].getTileType();
				
				if (tileMap[i + 2][j] == null) {
					break;
				}
				
				if (currType == tileMap[i+1][j].getTileType() && currType == tileMap[i+2][j].getTileType()) {
					//rewards points for a 3 match
					//System.out.println("3000 points" + i + ":" + j);
					tileMap[i][j] = new Tile(TileType.EMP, i, j);
					tileMap[i + 1][j] = new Tile(TileType.EMP, i, j);
					tileMap[i + 2][j] = new Tile(TileType.EMP, i, j);;
				}
			}
		}
	}
	
	public static void main(String args[]) {
		TileMap myTileMap = new TileMap(5, 5);
		myTileMap.fillMap(3);
		myTileMap.printMap();
		myTileMap.emptyMap();
		System.out.println();
		myTileMap.fillMap(4);
		myTileMap.printMap();
		myTileMap.emptyMap();
		System.out.println();
		myTileMap.fillMap(5);
		myTileMap.printMap();
		myTileMap.emptyMap();
		System.out.println();
		
		TileMap myBigTileMap = new TileMap(10,10);
		myBigTileMap.fillMap(3);
		myBigTileMap.printMap();
		myBigTileMap.emptyMap();
		System.out.println();
		myBigTileMap.fillMap(4);
		myBigTileMap.printMap();
		myBigTileMap.emptyMap();
		System.out.println();
		myBigTileMap.fillMap(5);
		myBigTileMap.printMap();
		myBigTileMap.findMatches();
		System.out.println();
		myBigTileMap.printMap();
		myBigTileMap.emptyMap();
		System.out.println();
		
	}
}