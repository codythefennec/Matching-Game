public enum TileType {
	HEART, CROSS, STAR, MOON, TRIS, EMP;
	
	public String getPath() {
		switch(this) {
			case HEART: return "heart.png";
			case CROSS:	return "cross.png";
			case STAR: return "star.png";
			case MOON: return "moon.png";
			case TRIS: return "tris.png";
			case EMP: return "empty.png";
		}
		return "n/a";
	}
	
	public String toString() {
		switch(this) {
			case HEART: return "h";
			case CROSS: return "c";
			case STAR: return "s";
			case MOON: return "m";
			case TRIS: return "t";
			case EMP: return "@";
		}
		return "n/a";
	}
}
