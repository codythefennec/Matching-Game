public class MapFunction {
	TileMap myMap;
	
	public MapFunction() {
		myMap = new TileMap(5, 5);
	}
	
	public MapFunction(int rows, int cols) {
		myMap = new TileMap(rows, cols);
	}
	
	//we need move function
	
	//clear tiles function #1
	
	
	
	//load more tiles goal
	
	//we need to make point <3 systems
	
	//
}