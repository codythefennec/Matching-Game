import java.util.Random;

public class RandomTile {
	// Instance of random class
		// TODO IMPLEMENT COMPLEXITY
	int complexity;
    Random rand = new Random(); 
    
    public int getComplexity() {
		return complexity;
	}

	public void setComplexity(int complexity) {
		this.complexity = complexity;
	}

	public RandomTile() {
    	this.complexity = 3;
    }
    
    public RandomTile(int complexity) {
    	if (complexity > 5) {
    		this.complexity = 5;
    	} else if (complexity < 3) {
    		this.complexity = 3;
    	} else {
    		this.complexity = complexity;
    	}
    }
    
    public TileType GetRandomTile() {
    	int switchInt = (1 + (Math.abs(rand.nextInt()) % complexity));
    	/*
    	System.out.println("Testing...");
    	for (int i = -5; i < 15; i++) {
    		System.out.println("i: " + i + " |||| " + (1 + (i % complexity)));
    	}
    	*/
    	//System.out.println(switchInt);
    	
    	TileType returnType = TileType.HEART;
    	
    	switch (switchInt) {
    		case 1:
    			returnType = TileType.HEART;
    			break;
    			
    		case 2:
    			returnType = TileType.CROSS;
    			break;
    		
    		case 3:
    			returnType = TileType.STAR;
    			break;
    			
    		case 4:
    			returnType = TileType.MOON;
    			break;
    			
    		case 5:
    			returnType = TileType.TRIS;
    			break;
    	}
    	
    	return returnType;
    }
    
    public static void main(String args[]) {
    	RandomTile myRandomTile = new RandomTile(3);
    	System.out.println("Output a single random tile ");
    	System.out.println(myRandomTile.GetRandomTile().toString());
    	System.out.println();
    	System.out.println("Output a few random tiles");
    	System.out.println();
    	for (int i = 0; i < 10; i++) {
    		System.out.println(myRandomTile.GetRandomTile().toString());
    		System.out.println();
    	}
    	System.out.println("Change complexity to 4");
    	myRandomTile.setComplexity(4);
    	System.out.println("Output a single random tile ");
    	System.out.println(myRandomTile.GetRandomTile().toString());
    	System.out.println();
    	System.out.println("Output a few random tiles");
    	System.out.println();
    	for (int i = 0; i < 10; i++) {
    		System.out.println(myRandomTile.GetRandomTile().toString());
    		System.out.println();
    	}
    	System.out.println("Change complexity to 5");
    	myRandomTile.setComplexity(5);
    	System.out.println("Output a single random tile ");
    	System.out.println(myRandomTile.GetRandomTile().toString());
    	System.out.println();
    	System.out.println("Output a few random tiles");
    	System.out.println();
    	for (int i = 0; i < 10; i++) {
    		System.out.println(myRandomTile.GetRandomTile().toString());
    		System.out.println();
    	}
    }
}

