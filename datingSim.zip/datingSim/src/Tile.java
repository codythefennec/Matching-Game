public class Tile {
	TileType tileType;
	double tileRow;
	double tileCol;
	
	public Tile(TileType tileType, int initRow, int initCol) {
		this.tileType = tileType;
		tileRow = initRow;
		tileCol = initCol;
	}

	public TileType getTileType() {
		return tileType;
	}

	public void setTileType(TileType tileType) {
		this.tileType = tileType;
	}
}